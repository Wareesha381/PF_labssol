#include<iostream>
#include<fstream>
#include<string>

using namespace std;
int main()
{
	ifstream file("integer.txt", ios::in);//read
	ofstream file1("result.txt", ios::out);//write
	float sum = 0;
	float average;
	int counter = 0;
		if (file.is_open())
		{
			string s;
		
			while (getline(file, s))
			{
				for (int i = 0;s[i] != '\0';i++)
				{
					{
						if(s[i]>='0'&&s[i]<='9')
							sum += (s[i] - '0');
						
						counter++;
					}
					
				}
			}
			
		}
		else
		{
			cout << "File does not opened successfully...Try Again" << endl;
		}
		average = sum / counter;
		if (file1.is_open())
		{
			file1 << "Sum: " << sum << endl;
			file1 << "Average: " << average;
		}
		file1.close();
		file.close();
		return 0;
}