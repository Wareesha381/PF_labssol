#include<iostream>
#include<fstream>
#include<string>

using namespace std;
int main()
{
	ifstream file("average.txt", ios::in);//read
	ofstream file1("newfile.txt", ios::out);//write


	if (file.is_open())
	{
		string s;
		int number;

		while (getline(file, s))
		{
			for(int i=0;s[i]!='\0';i++)
			{
				number = s[i] - '0';
				if (number >= 0 && number <= 9)
				{
					
					if (number < 4)
					{
						file1<< "Below Average";
						
					}
					else if (number >= 4 && number <= 6)
					{
						file1 << "ON Average";


					}
					else if (number > 6)
					{
						file1 << "Above Average ";
					}
				}
			}
			
			
		}

	}
	else
	{
		cout << "File does not opened successfully...Try Again" << endl;
	}

	file1.close();
	file.close();
	return 0;
}