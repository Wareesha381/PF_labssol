#include<iostream>
#include<fstream>
#include<string>

using namespace std;
int main()
{
	ifstream file("integer.txt", ios::in);//read
	ofstream temp("temp.txt", ios::out);//write
	int newnumber;
	cout << "Enter the number you want to insert: ";
	cin >> newnumber;
	if (file.is_open())
	{
		if (temp.is_open())
		{
			temp << newnumber;

		}
		string s;
		
		while(getline(file, s))
		{
			temp << s;
			file >> temp;
			cout << "Text inserted successfully";
		}



	}



	file.close();
	temp.close();
	return 0;
}