#include <iostream>
#include <fstream>

using namespace std;

int main() {
    ofstream file("integer.txt", ios::app); // Open file in append mode

    if (!file) {
        cout << "Error opening file!" << endl;
        return 1;
    }

    int n;
    cout << "Enter the number you want to insert: ";
    cin >> n;

    file << " " << n; // Append the number with a space for formatting

    file.close();
    cout << "Number inserted successfully!" << endl;

    return 0;
}
