#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main()
{
	//integer
	ifstream fin;
	fin.open("integer.txt");//read


	int num = 0;
	if (fin.is_open())
	{
		cout << "file opened\n";
	}
	else
	{
		cout << "File not opened..\n";
	}
	fin >> num;
	cout << num;
	fin.close();
	ofstream NewFile("NewFile.txt");//write
	NewFile << "Integer: ";
	NewFile << num;
	NewFile.close();



	//double
	float num_float = 0.0;
	ifstream infile;
	infile.open("float.txt");
	if (infile.is_open())
	{
		infile >> num_float;
		cout << num_float;
	}
	infile.close();

	ofstream NewFileappend("NewFile.txt", ios::app);//write
	NewFileappend << endl << "Float: ";
	NewFileappend << num_float;
	NewFileappend.close();



	//Boolean
	bool numbool = 1;
	ifstream numbol;
	numbol.open("boolean.txt");
	if (numbol.is_open())
	{
		numbol >> numbool;
		cout << numbool;
	}
	numbol.close();

	ofstream NewFilebool("NewFile.txt", ios::app);//write
	NewFilebool << endl << "Boolean: ";
	NewFilebool << numbool;
	NewFilebool.close();



	//double
	double numdouble = 0.0;
	ifstream filedouble;
	filedouble.open("infile.txt");
	if (filedouble.is_open())
	{
		filedouble >> numdouble;
		cout << numdouble;
	}
	filedouble.close();

	ofstream NewFiledouble("NewFile.txt", ios::app);//write
	NewFiledouble << endl << "Double: ";
	NewFiledouble << numdouble;
	NewFiledouble.close();




	//character
	char numchar = 0;
	ifstream filechar;
	filechar.open("character.txt");
	if (filechar.is_open())
	{
		filechar >> numchar;
		cout << numchar;
	}
	filechar.close();

	ofstream NewFilechar("NewFile.txt", ios::app);//write
	NewFilechar << endl << "Character: ";
	NewFilechar << numchar;
	NewFilechar.close();


	//Character array
	char arr[100];
	ifstream filechararray;
	filechararray.open("characterArray.txt");
	if (filechararray.is_open())
	{
		filechararray >> arr;
		cout << arr;
	}
	filechararray.close();

	ofstream NewFilechararray("NewFile.txt", ios::app);//write


	NewFilechararray << endl << "Character Array: ";
	string s;
	while (getline(filechararray, s))
	{
		NewFilechararray << s;
	}
	NewFilechararray.close();

	return 0;
}